import array
from ast import While

def matriz1():
    matriz1=(nif1, nombre1, edad1)
    return matriz1()


print("Bienvenidos al sistema de registro de Andalucia")
print("")
print("A continuacion apareceran las opciones a seleccionar: ")
print("1. Grabar")
print("2. Buscar")
print("3. Imprimir certificados")
print("4. Salir")
print("")
op=int(input("Que opcion desea seleccionar (1, 2, 3 o 4) "))
while op != 4:
    if op == 1:
        print("Ha seleccionado la opcion de grabar: ")
        print()
        nif1=input("Ingrese su NIF: ")
        nombre1=input("Ingrese su nombre: ")
        edad1=int(input("Ingrese su edad: "))
        matriz_1 = array.np([nif1, nombre1, edad1])   

    if op == 2:
        print("Ha seleccionado la opcion de busqueda: ")
        print()
        consulta_nif=input("Ingrese NIF a buscar: ")
        if consulta_nif == nif1:
            print("El NIF ingresado es:", nif1)
            print("El nombre registrado a ese NIF es: ", nombre1)
            print("La edad correspondiente a esta persona es: ", edad1)
        else:
            print("El NIF ingresado no esta en nuestros registros!!! ")

    if op == 3:
        print("Ha seleccionado la opcion de impresion de certificados: ")
        print()
        print("Seleccione una de las siguientes opciones: ")
        print("1. Imprimir Certificado de nacimiento")
        print("2. Imprimir Certificado de estado conyugal")
        print("3. Imprimir Certificado de perteneciente a Union Europea")
        op_certificado=int(input())
        if op_certificado==1:
            tipo_cert=("Certificado de nacimiento")
            nif_cert=int(input("Ingrese su NIF:"))
            nombre_cert=input("Ingrese su nombre: ")
            edad_cert=int(input("Ingrese su edad: "))
            fecha_nac=input("Ingrese fecha de nacimiento con palabras: ")
            print()
            print("Tipo de certificado: ", tipo_cert)
            print("Nombre: ", nombre_cert)
            print("edad: ", edad_cert)
            print("fecha de nacimiento: ", fecha_nac)

        if op_certificado == 2:
            tipo_cert=("Certificado de estado conyugal")
            nif_cert=int(input("Ingrese su NIF:"))
            nombre_cert=input("Ingrese su nombre: ")
            edad_cert=int(input("Ingrese su edad: "))
            estado_conyugal=input("Ingrese estado conyugal: ")
            print()
            print("Tipo de certificado: ", tipo_cert)
            print("Nombre: ", nombre_cert)
            print("edad: ", edad_cert)
            print("fecha de nacimiento: ", estado_conyugal)

        if op_certificado == 3:
            tipo_cert=("Certificado de perteneciente a Union Europea")
            nif_cert=int(input("Ingrese su NIF:"))
            nombre_cert=input("Ingrese su nombre: ")
            edad_cert=int(input("Ingrese su edad: "))
            pert_Union_eur=input("Ingrese si es perteneciente a la Union Europea: ")
            print()
            print("Tipo de certificado: ", tipo_cert)
            print("Nombre: ", nombre_cert)
            print("edad: ", edad_cert)
            print("fecha de nacimiento: ", pert_Union_eur)

    else:
        if op == 4:
            print(nombre1, "Muchas gracias por ingresar a nuestro sistema, Hasta luego!!!")
           
        
         



      